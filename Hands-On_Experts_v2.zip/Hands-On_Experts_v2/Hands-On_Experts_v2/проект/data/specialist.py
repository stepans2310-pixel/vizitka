"""
Модель специалиста (ORM SQLAlchemy)
"""

import sqlalchemy as sa
from .db_session import SqlAlchemyBase


class Specialist(SqlAlchemyBase):
    """
    Модель специалиста в базе данных.
    """
    __tablename__ = 'specialists'

    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    name = sa.Column(sa.String(100), nullable=False)
    role = sa.Column(sa.String(100), nullable=False)
    category = sa.Column(sa.String(50), nullable=True)
    description = sa.Column(sa.Text, nullable=False)
    avatar = sa.Column(sa.String(255), nullable=True)

    education_years = sa.Column(sa.Integer, default=0)
    education_place = sa.Column(sa.String(255), nullable=True)

    project1_name = sa.Column(sa.String(200), nullable=True)
    project1_description = sa.Column(sa.Text, nullable=True)
    project2_name = sa.Column(sa.String(200), nullable=True)
    project2_description = sa.Column(sa.Text, nullable=True)

    email = sa.Column(sa.String(100), nullable=True)
    phone = sa.Column(sa.String(20), nullable=True)
    telegram = sa.Column(sa.String(50), nullable=True)

    skills = sa.Column(sa.Text, nullable=True)

    rating = sa.Column(sa.Float, default=5.0)
    completed_projects = sa.Column(sa.Integer, default=0)
    hourly_rate = sa.Column(sa.Integer, default=0)
    available = sa.Column(sa.Boolean, default=True)

    sort_order = sa.Column(sa.Integer, default=0)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'role': self.role,
            'category': self.category,
            'description': self.description,
            'avatar': self.avatar,
            'education': {
                'years': self.education_years,
                'place': self.education_place
            },
            'projects': [
                {
                    'name': self.project1_name,
                    'description': self.project1_description
                },
                {
                    'name': self.project2_name,
                    'description': self.project2_description
                }
            ],
            'contacts': {
                'email': self.email,
                'phone': self.phone,
                'telegram': self.telegram
            },
            'skills': self.skills.split(',') if self.skills else [],
            'rating': self.rating,
            'completed_projects': self.completed_projects,
            'hourly_rate': self.hourly_rate,
            'available': self.available
        }

    def get_skills_list(self):
        if not self.skills:
            return []
        return [s.strip() for s in self.skills.split(',')]

    def __repr__(self):
        return f'<Specialist {self.id}: {self.name} ({self.role})>'

"""
Hands-On Experts — Платформа для поиска IT-специалистов
=======================================================

Веб-приложение для работодателей, позволяющее находить и нанимать
проверенных IT-специалистов с рейтингом и портфолио.

Авторы: Фёдор Иванов, Степан Петров
Яндекс.Лицей 2024

Технологии:
    - Flask 3.0 (веб-фреймворк)
    - SQLAlchemy (ORM для работы с БД)
    - Flask-Login (авторизация)
    - Bootstrap 5 (UI-фреймворк)
    - SQLite (база данных)
    - REST API (JSON)

Структура:
    - /           — страница авторизации
    - /main       — главная страница со специалистами
    - /admin      — админ-панель (только для админов)
    - /api        — документация API (только для админов)
    - /api/*      — REST API endpoints
"""

import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.utils import secure_filename
from data import db_session
from data.specialist import Specialist
from data.user import User

# ==================== КОНФИГУРАЦИЯ ====================
app = Flask(__name__)
app.config['SECRET_KEY'] = 'hands-on-experts-secret-key-2024'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

os.makedirs(os.path.join(app.root_path, app.config['UPLOAD_FOLDER']), exist_ok=True)

# Настройка Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth'
login_manager.login_message = 'Пожалуйста, войдите или зарегистрируйтесь'


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(int(user_id))


# ==================== АВТОРИЗАЦИЯ ====================
@app.route('/')
def auth():
    if current_user.is_authenticated:
        return redirect(url_for('main'))
    return render_template('auth.html')


@app.route('/login', methods=['POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main'))

    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')

    if not username or not password:
        flash('Заполните все поля', 'danger')
        return redirect(url_for('auth'))

    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.username == username).first()

    if user and user.check_password(password):
        login_user(user, remember=True)
        flash(f'Добро пожаловать, {user.username}!', 'success')
        return redirect(url_for('main'))
    else:
        flash('Неверное имя пользователя или пароль', 'danger')
        return redirect(url_for('auth'))


@app.route('/register', methods=['POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main'))

    username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '')
    password2 = request.form.get('password2', '')

    errors = []
    if not username or len(username) < 3:
        errors.append('Имя пользователя должно быть не менее 3 символов')
    if not email or '@' not in email:
        errors.append('Введите корректный email')
    if not password or len(password) < 4:
        errors.append('Пароль должен быть не менее 4 символов')
    if password != password2:
        errors.append('Пароли не совпадают')

    if errors:
        for error in errors:
            flash(error, 'danger')
        return redirect(url_for('auth'))

    db_sess = db_session.create_session()

    if db_sess.query(User).filter(User.username == username).first():
        flash('Пользователь с таким именем уже существует', 'danger')
        return redirect(url_for('auth'))

    if db_sess.query(User).filter(User.email == email).first():
        flash('Пользователь с таким email уже существует', 'danger')
        return redirect(url_for('auth'))

    user = User(username=username, email=email, is_admin=False)
    user.set_password(password)
    db_sess.add(user)
    db_sess.commit()

    flash('Регистрация прошла успешно! Теперь войдите.', 'success')
    return redirect(url_for('auth'))


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('auth'))


# ==================== ГЛАВНАЯ СТРАНИЦА ====================
@app.route('/main')
@login_required
def main():
    db_sess = db_session.create_session()
    specialists = db_sess.query(Specialist).order_by(Specialist.sort_order).all()
    
    # Получаем уникальные категории для фильтра
    categories = list(set([s.category for s in specialists if s.category]))
    
    return render_template('index.html', specialists=specialists, categories=categories)


@app.route('/contact', methods=['POST'])
@login_required
def contact():
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    message = request.form.get('message', '').strip()

    if not all([name, email, message]):
        flash('Заполните все поля формы', 'danger')
        return redirect(url_for('main'))

    print(f"📧 Новое сообщение от {name} ({email}):\n{message}")
    flash('Спасибо! Мы свяжемся с вами в ближайшее время.', 'success')
    return redirect(url_for('main'))


# ==================== АДМИН-ПАНЕЛЬ ====================
@app.route('/admin')
@login_required
def admin_panel():
    if not current_user.is_admin:
        flash('У вас нет доступа к админ-панели', 'danger')
        return redirect(url_for('main'))

    db_sess = db_session.create_session()
    specialists = db_sess.query(Specialist).order_by(Specialist.sort_order).all()
    users = db_sess.query(User).order_by(User.id).all()
    return render_template('admin.html', specialists=specialists, users=users)


@app.route('/admin/add_specialist', methods=['POST'])
@login_required
def add_specialist():
    if not current_user.is_admin:
        flash('У вас нет доступа', 'danger')
        return redirect(url_for('main'))

    avatar_path = None
    if 'avatar' in request.files:
        file = request.files['avatar']
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            unique_filename = f"{os.urandom(8).hex()}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(os.path.join(app.root_path, file_path))
            avatar_path = file_path

    db_sess = db_session.create_session()
    specialist = Specialist(
        name=request.form.get('name', '').strip(),
        role=request.form.get('role', '').strip(),
        category=request.form.get('category', '').strip(),
        description=request.form.get('description', '').strip(),
        education_years=int(request.form.get('education_years', 0) or 0),
        education_place=request.form.get('education_place', '').strip(),
        project1_name=request.form.get('project1_name', '').strip(),
        project1_description=request.form.get('project1_description', '').strip(),
        project2_name=request.form.get('project2_name', '').strip(),
        project2_description=request.form.get('project2_description', '').strip(),
        email=request.form.get('email', '').strip(),
        phone=request.form.get('phone', '').strip(),
        telegram=request.form.get('telegram', '').strip(),
        skills=request.form.get('skills', '').strip(),
        rating=float(request.form.get('rating', 5.0) or 5.0),
        completed_projects=int(request.form.get('completed_projects', 0) or 0),
        hourly_rate=int(request.form.get('hourly_rate', 0) or 0),
        available=request.form.get('available') == 'on',
        avatar=avatar_path,
        sort_order=int(request.form.get('sort_order', 0) or 0)
    )
    db_sess.add(specialist)
    db_sess.commit()
    flash('Специалист успешно добавлен!', 'success')
    return redirect(url_for('admin_panel'))


@app.route('/admin/edit_specialist/<int:specialist_id>', methods=['POST'])
@login_required
def edit_specialist(specialist_id):
    if not current_user.is_admin:
        flash('У вас нет доступа', 'danger')
        return redirect(url_for('main'))

    db_sess = db_session.create_session()
    specialist = db_sess.query(Specialist).get(specialist_id)

    if not specialist:
        flash('Специалист не найден', 'danger')
        return redirect(url_for('admin_panel'))

    if 'avatar' in request.files:
        file = request.files['avatar']
        if file and file.filename and allowed_file(file.filename):
            if specialist.avatar:
                old_path = os.path.join(app.root_path, specialist.avatar)
                if os.path.exists(old_path):
                    os.remove(old_path)

            filename = secure_filename(file.filename)
            unique_filename = f"{os.urandom(8).hex()}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(os.path.join(app.root_path, file_path))
            specialist.avatar = file_path

    specialist.name = request.form.get('name', '').strip()
    specialist.role = request.form.get('role', '').strip()
    specialist.category = request.form.get('category', '').strip()
    specialist.description = request.form.get('description', '').strip()
    specialist.education_years = int(request.form.get('education_years', 0) or 0)
    specialist.education_place = request.form.get('education_place', '').strip()
    specialist.project1_name = request.form.get('project1_name', '').strip()
    specialist.project1_description = request.form.get('project1_description', '').strip()
    specialist.project2_name = request.form.get('project2_name', '').strip()
    specialist.project2_description = request.form.get('project2_description', '').strip()
    specialist.email = request.form.get('email', '').strip()
    specialist.phone = request.form.get('phone', '').strip()
    specialist.telegram = request.form.get('telegram', '').strip()
    specialist.skills = request.form.get('skills', '').strip()
    specialist.rating = float(request.form.get('rating', 5.0) or 5.0)
    specialist.completed_projects = int(request.form.get('completed_projects', 0) or 0)
    specialist.hourly_rate = int(request.form.get('hourly_rate', 0) or 0)
    specialist.available = request.form.get('available') == 'on'

    db_sess.commit()
    flash('Специалист успешно обновлен!', 'success')
    return redirect(url_for('admin_panel'))


@app.route('/admin/delete_specialist/<int:specialist_id>')
@login_required
def delete_specialist(specialist_id):
    if not current_user.is_admin:
        flash('У вас нет доступа', 'danger')
        return redirect(url_for('main'))

    db_sess = db_session.create_session()
    specialist = db_sess.query(Specialist).get(specialist_id)

    if specialist:
        if specialist.avatar:
            avatar_path = os.path.join(app.root_path, specialist.avatar)
            if os.path.exists(avatar_path):
                os.remove(avatar_path)

        db_sess.delete(specialist)
        db_sess.commit()
        flash('Специалист удален!', 'success')

    return redirect(url_for('admin_panel'))


@app.route('/admin/make_admin/<int:user_id>')
@login_required
def make_admin(user_id):
    if not current_user.is_admin:
        flash('У вас нет доступа', 'danger')
        return redirect(url_for('main'))

    db_sess = db_session.create_session()
    user = db_sess.query(User).get(user_id)

    if user and not user.is_admin:
        user.is_admin = True
        db_sess.commit()
        flash(f'Пользователь {user.username} теперь администратор!', 'success')

    return redirect(url_for('admin_panel'))


@app.route('/admin/delete_user/<int:user_id>')
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        flash('У вас нет доступа', 'danger')
        return redirect(url_for('main'))

    if user_id == current_user.id:
        flash('Нельзя удалить самого себя', 'danger')
        return redirect(url_for('admin_panel'))

    db_sess = db_session.create_session()
    user = db_sess.query(User).get(user_id)

    if user:
        username = user.username
        db_sess.delete(user)
        db_sess.commit()
        flash(f'Пользователь {username} удален!', 'success')

    return redirect(url_for('admin_panel'))


# ==================== REST API ====================
@app.route('/api/specialists', methods=['GET'])
def api_get_specialists():
    db_sess = db_session.create_session()
    specialists = db_sess.query(Specialist).order_by(Specialist.sort_order).all()

    return jsonify({
        'success': True,
        'count': len(specialists),
        'specialists': [s.to_dict() for s in specialists]
    })


@app.route('/api/specialists/<int:specialist_id>', methods=['GET'])
def api_get_specialist(specialist_id):
    db_sess = db_session.create_session()
    specialist = db_sess.query(Specialist).get(specialist_id)

    if not specialist:
        return jsonify({
            'success': False,
            'error': 'Специалист не найден'
        }), 404

    return jsonify({
        'success': True,
        'specialist': specialist.to_dict()
    })


@app.route('/api/specialists/search', methods=['GET'])
def api_search_specialists():
    query = request.args.get('q', '').strip().lower()
    category = request.args.get('category', '').strip()
    available_only = request.args.get('available', '').lower() == 'true'

    db_sess = db_session.create_session()
    specialists = db_sess.query(Specialist)

    if available_only:
        specialists = specialists.filter(Specialist.available == True)

    if category:
        specialists = specialists.filter(Specialist.category == category)

    specialists = specialists.all()

    if query:
        specialists = [
            s for s in specialists
            if query in s.name.lower() or
               query in s.role.lower() or
               query in s.description.lower() or
               query in s.skills.lower()
        ]

    return jsonify({
        'success': True,
        'count': len(specialists),
        'specialists': [s.to_dict() for s in specialists]
    })


@app.route('/api/stats', methods=['GET'])
def api_stats():
    db_sess = db_session.create_session()

    total_specialists = db_sess.query(Specialist).count()
    available_specialists = db_sess.query(Specialist).filter(
        Specialist.available == True
    ).count()
    total_users = db_sess.query(User).count()
    total_projects = sum(
        s.completed_projects for s in db_sess.query(Specialist).all()
    )

    return jsonify({
        'success': True,
        'stats': {
            'total_specialists': total_specialists,
            'available_specialists': available_specialists,
            'total_users': total_users,
            'total_completed_projects': total_projects
        }
    })


# ==================== API СТРАНИЦА ====================
@app.route('/api')
@login_required
def api_docs():
    """Страница документации API (только для админов)"""
    if not current_user.is_admin:
        flash('У вас нет доступа к API-документации', 'danger')
        return redirect(url_for('main'))
    return render_template('api.html')


# ==================== РАСШИРЕННОЕ API ====================
@app.route('/api/specialists', methods=['POST'])
def api_create_specialist():
    api_key = request.headers.get('X-API-Key')
    if api_key != 'hands-on-experts-api-key-2024':
        return jsonify({'success': False, 'error': 'Неверный API-ключ'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'Нет данных'}), 400

    required = ['name', 'role', 'description']
    for field in required:
        if field not in data or not data[field]:
            return jsonify({'success': False, 'error': f'Поле {field} обязательно'}), 400

    db_sess = db_session.create_session()
    specialist = Specialist(
        name=data.get('name'),
        role=data.get('role'),
        category=data.get('category', ''),
        description=data.get('description'),
        education_years=data.get('education_years', 0),
        education_place=data.get('education_place', ''),
        project1_name=data.get('project1_name', ''),
        project1_description=data.get('project1_description', ''),
        project2_name=data.get('project2_name', ''),
        project2_description=data.get('project2_description', ''),
        email=data.get('email', ''),
        phone=data.get('phone', ''),
        telegram=data.get('telegram', ''),
        skills=data.get('skills', ''),
        rating=data.get('rating', 5.0),
        completed_projects=data.get('completed_projects', 0),
        hourly_rate=data.get('hourly_rate', 0),
        available=data.get('available', True)
    )
    db_sess.add(specialist)
    db_sess.commit()

    return jsonify({
        'success': True,
        'message': 'Специалист создан',
        'specialist': specialist.to_dict()
    }), 201


@app.route('/api/specialists/<int:specialist_id>', methods=['PUT'])
def api_update_specialist(specialist_id):
    api_key = request.headers.get('X-API-Key')
    if api_key != 'hands-on-experts-api-key-2024':
        return jsonify({'success': False, 'error': 'Неверный API-ключ'}), 401

    db_sess = db_session.create_session()
    specialist = db_sess.query(Specialist).get(specialist_id)
    if not specialist:
        return jsonify({'success': False, 'error': 'Специалист не найден'}), 404

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'Нет данных'}), 400

    fields = [
        'name', 'role', 'category', 'description', 'education_years', 'education_place',
        'project1_name', 'project1_description', 'project2_name', 'project2_description',
        'email', 'phone', 'telegram', 'skills', 'rating', 'completed_projects',
        'hourly_rate', 'available'
    ]
    for field in fields:
        if field in data:
            setattr(specialist, field, data[field])

    db_sess.commit()
    return jsonify({
        'success': True,
        'message': 'Специалист обновлён',
        'specialist': specialist.to_dict()
    })


@app.route('/api/specialists/<int:specialist_id>', methods=['DELETE'])
def api_delete_specialist(specialist_id):
    api_key = request.headers.get('X-API-Key')
    if api_key != 'hands-on-experts-api-key-2024':
        return jsonify({'success': False, 'error': 'Неверный API-ключ'}), 401

    db_sess = db_session.create_session()
    specialist = db_sess.query(Specialist).get(specialist_id)
    if not specialist:
        return jsonify({'success': False, 'error': 'Специалист не найден'}), 404

    db_sess.delete(specialist)
    db_sess.commit()
    return jsonify({'success': True, 'message': 'Специалист удалён'})


@app.route('/api/categories', methods=['GET'])
def api_categories():
    db_sess = db_session.create_session()
    specialists = db_sess.query(Specialist).all()
    categories = {}
    for s in specialists:
        cat = s.category or 'Без категории'
        categories[cat] = categories.get(cat, 0) + 1
    return jsonify({
        'success': True,
        'categories': categories
    })


# ==================== ОБРАБОТКА ОШИБОК ====================
@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html',
                           error_code=404,
                           error_message='Страница не найдена'), 404


@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html',
                           error_code=500,
                           error_message='Внутренняя ошибка сервера'), 500


# ==================== ИНИЦИАЛИЗАЦИЯ ====================
def init_database():
    """Инициализация базы данных с 20 специалистами"""
    db_session.global_init('team_portfolio.db')
    db_sess = db_session.create_session()

    if db_sess.query(Specialist).count() == 0:
        print("📝 Создание 20 специалистов...")

        specialists_data = [
            {
                'name': 'Фёдор Иванов',
                'role': 'Senior Backend Developer',
                'category': 'Backend',
                'description': 'Архитектор серверных решений с 5-летним опытом. Специализируюсь на высоконагруженных системах, микросервисной архитектуре и оптимизации производительности.',
                'education_years': 4,
                'education_place': 'МГУ им. Ломоносова, факультет ВМК + Яндекс.Лицей',
                'project1_name': 'Платёжная система для банка',
                'project1_description': 'Разработка API обработки 10000+ транзакций в секунду',
                'project2_name': 'Микросервисная платформа',
                'project2_description': 'Архитектура из 50+ сервисов для e-commerce',
                'email': 'fedor@experts.ru',
                'phone': '+7 (999) 111-22-33',
                'telegram': '@fedor_backend',
                'skills': 'Python, Go, PostgreSQL, Redis, Kafka, Docker, K8s, gRPC',
                'rating': 4.9,
                'completed_projects': 47,
                'hourly_rate': 5000,
                'available': True,
                'sort_order': 1
            },
            {
                'name': 'Степан Петров',
                'role': 'Lead Frontend Developer',
                'category': 'Frontend',
                'description': 'Создаю современные веб-интерфейсы с фокусом на UX и производительность. Эксперт в React экосистеме и современных CSS-технологиях.',
                'education_years': 3,
                'education_place': 'МФТИ + курсы Яндекс.Практикум',
                'project1_name': 'Админ-панель для SaaS',
                'project1_description': 'Комплексный дашборд с real-time графиками',
                'project2_name': 'E-commerce платформа',
                'project2_description': 'PWA магазин с офлайн-режимом',
                'email': 'stepan@experts.ru',
                'phone': '+7 (999) 222-33-44',
                'telegram': '@stepan_front',
                'skills': 'React, TypeScript, Next.js, Tailwind, GraphQL, Three.js',
                'rating': 4.8,
                'completed_projects': 38,
                'hourly_rate': 4500,
                'available': True,
                'sort_order': 2
            },
            {
                'name': 'Алексей Сидоров',
                'role': 'Full-Stack Developer',
                'category': 'Full-Stack',
                'description': 'Универсальный разработчик, способный реализовать проект от идеи до продакшена. Опыт работы со стартапами и enterprise-решениями.',
                'education_years': 5,
                'education_place': 'СПбГУ, прикладная математика',
                'project1_name': 'CRM-система для агентства',
                'project1_description': 'Полный цикл разработки от БД до UI',
                'project2_name': 'Маркетплейс услуг',
                'project2_description': 'MVP за 2 месяца, 10000+ пользователей',
                'email': 'alexey@experts.ru',
                'phone': '+7 (999) 333-44-55',
                'telegram': '@alexey_fullstack',
                'skills': 'Python, JavaScript, React, Node.js, PostgreSQL, AWS',
                'rating': 4.7,
                'completed_projects': 52,
                'hourly_rate': 4000,
                'available': True,
                'sort_order': 3
            },
            {
                'name': 'Мария Козлова',
                'role': 'UI/UX Designer',
                'category': 'Design',
                'description': 'Дизайнер с опытом в продуктовых командах. Создаю интуитивные интерфейсы на основе исследований пользователей и data-driven подхода.',
                'education_years': 4,
                'education_place': 'Британская высшая школа дизайна',
                'project1_name': 'Редизайн банковского приложения',
                'project1_description': 'Увеличение конверсии на 40%',
                'project2_name': 'Дизайн-система для стартапа',
                'project2_description': '200+ компонентов в Figma',
                'email': 'maria@experts.ru',
                'phone': '+7 (999) 444-55-66',
                'telegram': '@maria_design',
                'skills': 'Figma, Sketch, Prototyping, User Research, Design Systems',
                'rating': 4.9,
                'completed_projects': 63,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 4
            },
            {
                'name': 'Дмитрий Волков',
                'role': 'DevOps Engineer',
                'category': 'DevOps',
                'description': 'Строю надёжную инфраструктуру и автоматизирую всё, что можно автоматизировать. Эксперт в облачных технологиях и CI/CD.',
                'education_years': 3,
                'education_place': 'МГТУ им. Баумана + сертификации AWS/GCP',
                'project1_name': 'Миграция в Kubernetes',
                'project1_description': 'Перенос 100+ сервисов в K8s кластер',
                'project2_name': 'CI/CD пайплайн',
                'project2_description': 'Сокращение времени деплоя с 2 часов до 10 минут',
                'email': 'dmitry@experts.ru',
                'phone': '+7 (999) 555-66-77',
                'telegram': '@dmitry_devops',
                'skills': 'Docker, Kubernetes, Terraform, Ansible, GitLab CI, AWS, GCP',
                'rating': 4.8,
                'completed_projects': 29,
                'hourly_rate': 5500,
                'available': False,
                'sort_order': 5
            },
            {
                'name': 'Анна Белова',
                'role': 'Data Scientist',
                'category': 'Data Science',
                'description': 'Превращаю данные в бизнес-ценность. Специализируюсь на ML-моделях, предиктивной аналитике и NLP.',
                'education_years': 6,
                'education_place': 'НИУ ВШЭ, магистратура + аспирантура',
                'project1_name': 'Рекомендательная система',
                'project1_description': 'ML-модель для персонализации контента',
                'project2_name': 'Fraud Detection',
                'project2_description': 'Система обнаружения мошенничества',
                'email': 'anna@experts.ru',
                'phone': '+7 (999) 666-77-88',
                'telegram': '@anna_data',
                'skills': 'Python, TensorFlow, PyTorch, Pandas, SQL, MLflow, Spark',
                'rating': 4.9,
                'completed_projects': 21,
                'hourly_rate': 6000,
                'available': True,
                'sort_order': 6
            },
            {
                'name': 'Игорь Морозов',
                'role': 'Mobile Developer',
                'category': 'Mobile',
                'description': 'Разрабатываю нативные и кроссплатформенные мобильные приложения. Опыт публикации в App Store и Google Play.',
                'education_years': 4,
                'education_place': 'ИТМО, программная инженерия',
                'project1_name': 'Fitness-приложение',
                'project1_description': '500K+ скачиваний, рейтинг 4.8',
                'project2_name': 'Банковское приложение',
                'project2_description': 'Flutter-клиент для необанка',
                'email': 'igor@experts.ru',
                'phone': '+7 (999) 777-88-99',
                'telegram': '@igor_mobile',
                'skills': 'Swift, Kotlin, Flutter, React Native, Firebase',
                'rating': 4.7,
                'completed_projects': 34,
                'hourly_rate': 4500,
                'available': True,
                'sort_order': 7
            },
            {
                'name': 'Екатерина Новикова',
                'role': 'QA Engineer',
                'category': 'QA',
                'description': 'Обеспечиваю качество на всех этапах разработки. Эксперт в автоматизации тестирования и построении QA-процессов.',
                'education_years': 3,
                'education_place': 'Курсы Яндекс.Практикум + ISTQB сертификация',
                'project1_name': 'Автоматизация тестирования',
                'project1_description': 'Покрытие 85% автотестами',
                'project2_name': 'QA-процессы с нуля',
                'project2_description': 'Внедрение тестирования в стартапе',
                'email': 'kate@experts.ru',
                'phone': '+7 (999) 888-99-00',
                'telegram': '@kate_qa',
                'skills': 'Selenium, Pytest, Postman, JMeter, TestRail, Allure',
                'rating': 4.6,
                'completed_projects': 28,
                'hourly_rate': 3000,
                'available': True,
                'sort_order': 8
            },
            {
                'name': 'Максим Кузнецов',
                'role': 'System Administrator',
                'category': 'DevOps',
                'description': 'Поддерживаю стабильную работу серверной инфраструктуры. Опыт работы с высоконагруженными системами 24/7.',
                'education_years': 5,
                'education_place': 'МАИ + сертификации Red Hat, Cisco',
                'project1_name': 'Отказоустойчивый кластер',
                'project1_description': 'Uptime 99.99% для критичных сервисов',
                'project2_name': 'Мониторинг инфраструктуры',
                'project2_description': 'Prometheus + Grafana для 500+ серверов',
                'email': 'maxim@experts.ru',
                'phone': '+7 (999) 999-00-11',
                'telegram': '@maxim_admin',
                'skills': 'Linux, Nginx, PostgreSQL, Prometheus, Grafana, Zabbix',
                'rating': 4.8,
                'completed_projects': 45,
                'hourly_rate': 3500,
                'available': False,
                'sort_order': 9
            },
            {
                'name': 'Ольга Соколова',
                'role': 'Project Manager',
                'category': 'Management',
                'description': 'Управляю IT-проектами по Agile/Scrum. Опыт работы с распределёнными командами и бюджетами до $1M.',
                'education_years': 4,
                'education_place': 'РЭУ им. Плеханова + PMI сертификация',
                'project1_name': 'Запуск fintech-стартапа',
                'project1_description': 'От идеи до 50K пользователей за год',
                'project2_name': 'Цифровая трансформация',
                'project2_description': 'Внедрение ERP в компании 1000+ сотрудников',
                'email': 'olga@experts.ru',
                'phone': '+7 (999) 000-11-22',
                'telegram': '@olga_pm',
                'skills': 'Scrum, Kanban, Jira, Confluence, Risk Management, Budgeting',
                'rating': 4.9,
                'completed_projects': 18,
                'hourly_rate': 4000,
                'available': True,
                'sort_order': 10
            },
            {
                'name': 'Артём Лебедев',
                'role': 'Blockchain Developer',
                'category': 'Blockchain',
                'description': 'Разрабатываю смарт-контракты и DeFi-решения. Эксперт в Ethereum, Solana и cross-chain технологиях.',
                'education_years': 3,
                'education_place': 'Самообразование + курсы ConsenSys Academy',
                'project1_name': 'DEX платформа',
                'project1_description': 'Децентрализованная биржа на Uniswap fork',
                'project2_name': 'NFT маркетплейс',
                'project2_description': 'Платформа для создания и продажи NFT',
                'email': 'artem@experts.ru',
                'phone': '+7 (999) 111-22-33',
                'telegram': '@artem_blockchain',
                'skills': 'Solidity, Rust, Web3.js, Hardhat, IPFS, TheGraph',
                'rating': 4.7,
                'completed_projects': 15,
                'hourly_rate': 7000,
                'available': True,
                'sort_order': 11
            },
            {
                'name': 'Наталья Фёдорова',
                'role': 'Technical Writer',
                'category': 'Documentation',
                'description': 'Создаю понятную техническую документацию. Опыт работы с API-документацией и пользовательскими руководствами.',
                'education_years': 4,
                'education_place': 'МГУ, филологический факультет + IT-курсы',
                'project1_name': 'API Documentation',
                'project1_description': 'Документация для REST API с 200+ endpoints',
                'project2_name': 'Knowledge Base',
                'project2_description': 'База знаний для SaaS-продукта',
                'email': 'natalia@experts.ru',
                'phone': '+7 (999) 222-33-44',
                'telegram': '@natalia_docs',
                'skills': 'Markdown, OpenAPI, Confluence, GitBook, Диаграммы',
                'rating': 4.8,
                'completed_projects': 32,
                'hourly_rate': 2500,
                'available': True,
                'sort_order': 12
            },
            {
                'name': 'Павел Орлов',
                'role': 'Game Developer',
                'category': 'GameDev',
                'description': 'Создаю игры на Unity и Unreal Engine. Опыт разработки мобильных, PC и VR-игр.',
                'education_years': 4,
                'education_place': 'Scream School + самообразование',
                'project1_name': 'Мобильная игра',
                'project1_description': 'Казуальная игра, 1M+ скачиваний',
                'project2_name': 'VR-симулятор',
                'project2_description': 'Образовательный VR-проект для музея',
                'email': 'pavel@experts.ru',
                'phone': '+7 (999) 333-44-55',
                'telegram': '@pavel_gamedev',
                'skills': 'Unity, C#, Unreal Engine, Blender, Shader Programming',
                'rating': 4.6,
                'completed_projects': 12,
                'hourly_rate': 4000,
                'available': True,
                'sort_order': 13
            },
            {
                'name': 'Виктория Смирнова',
                'role': 'SEO Specialist',
                'category': 'Marketing',
                'description': 'Продвигаю сайты в поисковых системах. Опыт работы с крупными e-commerce проектами и информационными сайтами.',
                'education_years': 3,
                'education_place': 'Курсы Яндекс + Google сертификации',
                'project1_name': 'SEO для интернет-магазина',
                'project1_description': 'Рост органического трафика в 5 раз',
                'project2_name': 'Локальное SEO',
                'project2_description': 'ТОП-3 по ключевым запросам в регионе',
                'email': 'victoria@experts.ru',
                'phone': '+7 (999) 444-55-66',
                'telegram': '@victoria_seo',
                'skills': 'SEO-аудит, Семантика, Link Building, Яндекс.Метрика, GA4',
                'rating': 4.7,
                'completed_projects': 41,
                'hourly_rate': 3000,
                'available': False,
                'sort_order': 14
            },
            {
                'name': 'Роман Захаров',
                'role': 'Security Engineer',
                'category': 'Security',
                'description': 'Обеспечиваю безопасность приложений и инфраструктуры. Провожу пентесты и аудиты безопасности.',
                'education_years': 5,
                'education_place': 'МИФИ + OSCP, CEH сертификации',
                'project1_name': 'Пентест банковской системы',
                'project1_description': 'Выявление критических уязвимостей',
                'project2_name': 'Security Operations Center',
                'project2_description': 'Построение SOC для финтех-компании',
                'email': 'roman@experts.ru',
                'phone': '+7 (999) 555-66-77',
                'telegram': '@roman_security',
                'skills': 'Pentesting, SIEM, WAF, Cryptography, Compliance',
                'rating': 4.9,
                'completed_projects': 24,
                'hourly_rate': 6500,
                'available': True,
                'sort_order': 15
            },
            {
                'name': 'Елена Попова',
                'role': '1C Developer',
                'category': 'Enterprise',
                'description': 'Разрабатываю и внедряю решения на платформе 1С. Опыт автоматизации бухгалтерии и управленческого учёта.',
                'education_years': 4,
                'education_place': 'Финансовый университет + сертификаты 1С',
                'project1_name': 'Внедрение 1С:ERP',
                'project1_description': 'Автоматизация производственной компании',
                'project2_name': 'Интеграция 1С и сайта',
                'project2_description': 'Синхронизация данных в реальном времени',
                'email': 'elena@experts.ru',
                'phone': '+7 (999) 666-77-88',
                'telegram': '@elena_1c',
                'skills': '1С:Предприятие, SQL, REST API, Интеграции, Отчёты',
                'rating': 4.8,
                'completed_projects': 56,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 16
            },
            {
                'name': 'Андрей Титов',
                'role': 'ML Engineer',
                'category': 'Data Science',
                'description': 'Внедряю ML-модели в продакшен. Специализируюсь на MLOps, оптимизации моделей и real-time inference.',
                'education_years': 5,
                'education_place': 'Сколтех, магистратура Computer Science',
                'project1_name': 'Real-time ML Pipeline',
                'project1_description': 'Обработка 100K событий в секунду',
                'project2_name': 'Computer Vision система',
                'project2_description': 'Детекция дефектов на производстве',
                'email': 'andrey@experts.ru',
                'phone': '+7 (999) 777-88-99',
                'telegram': '@andrey_ml',
                'skills': 'Python, MLflow, Kubeflow, TensorRT, ONNX, FastAPI',
                'rating': 4.9,
                'completed_projects': 19,
                'hourly_rate': 5500,
                'available': True,
                'sort_order': 17
            },
            {
                'name': 'Дарья Волкова',
                'role': 'Motion Designer',
                'category': 'Design',
                'description': 'Создаю анимации для веб, мобильных приложений и рекламы. Опыт работы с 2D и 3D графикой.',
                'education_years': 3,
                'education_place': 'Школа дизайна НИУ ВШЭ',
                'project1_name': 'Анимированный лендинг',
                'project1_description': 'Интерактивные анимации для tech-стартапа',
                'project2_name': 'Рекламные ролики',
                'project2_description': 'Серия видео для социальных сетей',
                'email': 'daria@experts.ru',
                'phone': '+7 (999) 888-99-00',
                'telegram': '@daria_motion',
                'skills': 'After Effects, Cinema 4D, Lottie, GSAP, Blender',
                'rating': 4.7,
                'completed_projects': 48,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 18
            },
            {
                'name': 'Сергей Николаев',
                'role': 'Embedded Developer',
                'category': 'Embedded',
                'description': 'Разрабатываю ПО для встраиваемых систем и IoT-устройств. Опыт работы с микроконтроллерами и RTOS.',
                'education_years': 5,
                'education_place': 'МГТУ им. Баумана, робототехника',
                'project1_name': 'IoT-платформа',
                'project1_description': 'Система мониторинга для умного дома',
                'project2_name': 'Firmware для устройства',
                'project2_description': 'Прошивка для медицинского прибора',
                'email': 'sergey@experts.ru',
                'phone': '+7 (999) 999-00-11',
                'telegram': '@sergey_embedded',
                'skills': 'C, C++, STM32, ESP32, FreeRTOS, Protocol Buffers',
                'rating': 4.8,
                'completed_projects': 23,
                'hourly_rate': 4500,
                'available': False,
                'sort_order': 19
            },
            {
                'name': 'Алина Краснова',
                'role': 'Product Manager',
                'category': 'Management',
                'description': 'Управляю развитием digital-продуктов. Опыт работы в стартапах и крупных tech-компаниях.',
                'education_years': 4,
                'education_place': 'Школа менеджеров Яндекса',
                'project1_name': 'Запуск нового продукта',
                'project1_description': 'Product-market fit за 6 месяцев',
                'project2_name': 'Оптимизация воронки',
                'project2_description': 'Рост конверсии на 60%',
                'email': 'alina@experts.ru',
                'phone': '+7 (999) 000-11-22',
                'telegram': '@alina_product',
                'skills': 'Product Strategy, Analytics, A/B Testing, Roadmapping',
                'rating': 4.9,
                'completed_projects': 14,
                'hourly_rate': 4500,
                'available': True,
                'sort_order': 20
            },
            {
                'name': 'Кирилл Воронов',
                'role': 'Backend Developer (Java)',
                'category': 'Backend',
                'description': 'Enterprise-разработчик на Java/Spring. Опыт создания банковских систем и высоконагруженных сервисов.',
                'education_years': 5,
                'education_place': 'МИФИ, прикладная информатика',
                'project1_name': 'Процессинговый центр',
                'project1_description': 'Обработка банковских транзакций 24/7',
                'project2_name': 'Система лояльности',
                'project2_description': 'Микросервисы для программы лояльности сети',
                'email': 'kirill@experts.ru',
                'phone': '+7 (999) 101-20-30',
                'telegram': '@kirill_java',
                'skills': 'Java, Spring Boot, Hibernate, Kafka, Oracle, Microservices',
                'rating': 4.8,
                'completed_projects': 33,
                'hourly_rate': 5000,
                'available': True,
                'sort_order': 21
            },
            {
                'name': 'Полина Егорова',
                'role': 'Frontend Developer (Vue)',
                'category': 'Frontend',
                'description': 'Разработка SPA на Vue.js и Nuxt. Создание UI-библиотек и дизайн-систем для крупных проектов.',
                'education_years': 3,
                'education_place': 'Университет ИТМО + Hexlet',
                'project1_name': 'Корпоративный портал',
                'project1_description': 'Vue 3 + TypeScript, 50+ страниц',
                'project2_name': 'UI-библиотека',
                'project2_description': 'Открытая библиотека компонентов, 2K+ stars',
                'email': 'polina@experts.ru',
                'phone': '+7 (999) 102-30-40',
                'telegram': '@polina_vue',
                'skills': 'Vue.js, Nuxt, TypeScript, Pinia, Vite, Storybook',
                'rating': 4.7,
                'completed_projects': 26,
                'hourly_rate': 4000,
                'available': True,
                'sort_order': 22
            },
            {
                'name': 'Денис Марков',
                'role': 'Cloud Architect',
                'category': 'DevOps',
                'description': 'Проектирование облачной инфраструктуры. AWS Solutions Architect Professional, опыт миграции enterprise-систем.',
                'education_years': 6,
                'education_place': 'МГТУ Баумана + AWS certifications',
                'project1_name': 'Миграция в облако',
                'project1_description': 'Перенос on-premise инфраструктуры на AWS, экономия 40%',
                'project2_name': 'Serverless платформа',
                'project2_description': 'Event-driven архитектура на Lambda + DynamoDB',
                'email': 'denis@experts.ru',
                'phone': '+7 (999) 103-40-50',
                'telegram': '@denis_cloud',
                'skills': 'AWS, Azure, Terraform, CloudFormation, Lambda, EKS',
                'rating': 4.9,
                'completed_projects': 22,
                'hourly_rate': 6500,
                'available': False,
                'sort_order': 23
            },
            {
                'name': 'Светлана Орлова',
                'role': 'Data Engineer',
                'category': 'Data Science',
                'description': 'Построение ETL-пайплайнов и data-платформ. Работа с петабайтами данных в real-time.',
                'education_years': 4,
                'education_place': 'НИУ ВШЭ, бизнес-информатика',
                'project1_name': 'Data Lake',
                'project1_description': 'Централизованное хранилище на 50TB+ данных',
                'project2_name': 'Streaming pipeline',
                'project2_description': 'Обработка 1M+ событий/мин на Flink',
                'email': 'svetlana@experts.ru',
                'phone': '+7 (999) 104-50-60',
                'telegram': '@svetlana_data',
                'skills': 'Python, Spark, Airflow, Kafka, Flink, dbt, Snowflake',
                'rating': 4.8,
                'completed_projects': 17,
                'hourly_rate': 5500,
                'available': True,
                'sort_order': 24
            },
            {
                'name': 'Тимур Гасанов',
                'role': 'iOS Developer',
                'category': 'Mobile',
                'description': 'Нативная разработка под iOS. SwiftUI, Combine, Core Data. Опыт публикации в App Store.',
                'education_years': 4,
                'education_place': 'Казанский федеральный университет',
                'project1_name': 'Приложение для доставки',
                'project1_description': '200K+ скачиваний, рейтинг 4.9',
                'project2_name': 'Финтех-приложение',
                'project2_description': 'Управление инвестициями с real-time котировками',
                'email': 'timur@experts.ru',
                'phone': '+7 (999) 105-60-70',
                'telegram': '@timur_ios',
                'skills': 'Swift, SwiftUI, UIKit, Combine, Core Data, ARKit',
                'rating': 4.7,
                'completed_projects': 19,
                'hourly_rate': 4500,
                'available': True,
                'sort_order': 25
            },
            {
                'name': 'Юлия Белкина',
                'role': 'UX Researcher',
                'category': 'Design',
                'description': 'Исследования пользователей и юзабилити-тестирование. Помогаю командам создавать продукты, которые любят.',
                'education_years': 4,
                'education_place': 'МГУ, психология + Google UX Design Certificate',
                'project1_name': 'Редизайн checkout',
                'project1_description': 'Снижение abandon rate на 35%',
                'project2_name': 'Юзабилити-аудит',
                'project2_description': 'Комплексный аудит SaaS-платформы',
                'email': 'yulia@experts.ru',
                'phone': '+7 (999) 106-70-80',
                'telegram': '@yulia_ux',
                'skills': 'User Research, Usability Testing, CJM, Personas, A/B Testing',
                'rating': 4.9,
                'completed_projects': 44,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 26
            },
            {
                'name': 'Владислав Семёнов',
                'role': 'SRE Engineer',
                'category': 'DevOps',
                'description': 'Site Reliability Engineering. Обеспечение надёжности и масштабируемости production-систем.',
                'education_years': 5,
                'education_place': 'МФТИ + Google SRE курсы',
                'project1_name': 'Система оркестрации',
                'project1_description': 'Автоматическое восстановление сервисов',
                'project2_name': 'Chaos Engineering',
                'project2_description': 'Внедрение chaos monkey в production',
                'email': 'vladislav@experts.ru',
                'phone': '+7 (999) 107-80-90',
                'telegram': '@vlad_sre',
                'skills': 'Linux, Kubernetes, Prometheus, Grafana, Go, Chaos Eng',
                'rating': 4.8,
                'completed_projects': 16,
                'hourly_rate': 6000,
                'available': True,
                'sort_order': 27
            },
            {
                'name': 'Диана Рыжова',
                'role': 'Android Developer',
                'category': 'Mobile',
                'description': 'Нативная Android-разработка на Kotlin. Jetpack Compose, MVVM, чистая архитектура.',
                'education_years': 3,
                'education_place': 'Новосибирский госуниверситет + Android Academy',
                'project1_name': 'Супер-апп для банка',
                'project1_description': 'Kotlin + Compose, 1M+ пользователей',
                'project2_name': 'Приложение для здоровья',
                'project2_description': 'Интеграция с wearables, Google Fit',
                'email': 'diana@experts.ru',
                'phone': '+7 (999) 108-90-01',
                'telegram': '@diana_android',
                'skills': 'Kotlin, Jetpack Compose, Coroutines, Dagger, Room, Retrofit',
                'rating': 4.6,
                'completed_projects': 21,
                'hourly_rate': 4000,
                'available': False,
                'sort_order': 28
            },
            {
                'name': 'Артур Мирзоев',
                'role': 'Cybersecurity Analyst',
                'category': 'Security',
                'description': 'Анализ угроз и инцидентов безопасности. Построение SIEM-систем и реагирование на атаки.',
                'education_years': 5,
                'education_place': 'МИФИ, информационная безопасность',
                'project1_name': 'Incident Response',
                'project1_description': 'Расследование APT-атаки на корпорацию',
                'project2_name': 'SIEM внедрение',
                'project2_description': 'Развёртывание Elastic SIEM для 10K+ хостов',
                'email': 'artur@experts.ru',
                'phone': '+7 (999) 109-01-12',
                'telegram': '@artur_sec',
                'skills': 'SIEM, Threat Hunting, Forensics, OSINT, Splunk, ELK',
                'rating': 4.9,
                'completed_projects': 31,
                'hourly_rate': 6000,
                'available': True,
                'sort_order': 29
            },
            {
                'name': 'Марина Черных',
                'role': 'Scrum Master',
                'category': 'Management',
                'description': 'Сертифицированный Scrum Master. Помогаю командам выстраивать процессы и повышать velocity.',
                'education_years': 3,
                'education_place': 'PSM I, PSM II, SAFe Agilist',
                'project1_name': 'Agile-трансформация',
                'project1_description': 'Переход с Waterfall на Scrum для 8 команд',
                'project2_name': 'Повышение velocity',
                'project2_description': 'Рост скорости команды на 80% за полгода',
                'email': 'marina@experts.ru',
                'phone': '+7 (999) 110-12-23',
                'telegram': '@marina_scrum',
                'skills': 'Scrum, SAFe, Kanban, Facilitation, Coaching, Miro',
                'rating': 4.8,
                'completed_projects': 25,
                'hourly_rate': 4000,
                'available': True,
                'sort_order': 30
            },
            {
                'name': 'Николай Громов',
                'role': 'Database Administrator',
                'category': 'Backend',
                'description': 'Администрирование и оптимизация баз данных. PostgreSQL, MySQL, MongoDB в production.',
                'education_years': 6,
                'education_place': 'МГТУ Баумана + PostgreSQL сертификации',
                'project1_name': 'Оптимизация БД',
                'project1_description': 'Ускорение запросов в 100 раз для highload',
                'project2_name': 'Миграция данных',
                'project2_description': 'Zero-downtime миграция 500GB базы',
                'email': 'nikolay@experts.ru',
                'phone': '+7 (999) 111-23-34',
                'telegram': '@nikolay_dba',
                'skills': 'PostgreSQL, MySQL, MongoDB, Redis, Patroni, PgBouncer',
                'rating': 4.9,
                'completed_projects': 38,
                'hourly_rate': 5000,
                'available': True,
                'sort_order': 31
            },
            {
                'name': 'Валерия Ковалёва',
                'role': 'Content Designer',
                'category': 'Design',
                'description': 'UX-тексты и контент-стратегия. Делаю интерфейсы понятными через правильные формулировки.',
                'education_years': 3,
                'education_place': 'Школа редакторов Бюро Горбунова',
                'project1_name': 'UX-копирайтинг',
                'project1_description': 'Редизайн текстов для мобильного банка',
                'project2_name': 'Tone of Voice',
                'project2_description': 'Разработка голоса бренда для стартапа',
                'email': 'valeria@experts.ru',
                'phone': '+7 (999) 112-34-45',
                'telegram': '@valeria_content',
                'skills': 'UX Writing, Copywriting, Content Strategy, Figma, Notion',
                'rating': 4.7,
                'completed_projects': 51,
                'hourly_rate': 2500,
                'available': True,
                'sort_order': 32
            },
            {
                'name': 'Олег Тарасов',
                'role': 'Network Engineer',
                'category': 'DevOps',
                'description': 'Проектирование и администрирование сетевой инфраструктуры. Cisco, Juniper, SD-WAN.',
                'education_years': 5,
                'education_place': 'МТУСИ + CCNP, JNCIS',
                'project1_name': 'Корпоративная сеть',
                'project1_description': 'Проектирование сети на 2000+ устройств',
                'project2_name': 'SD-WAN внедрение',
                'project2_description': 'Объединение 50 филиалов',
                'email': 'oleg@experts.ru',
                'phone': '+7 (999) 113-45-56',
                'telegram': '@oleg_network',
                'skills': 'Cisco, Juniper, SD-WAN, BGP, OSPF, Firewall, VPN',
                'rating': 4.8,
                'completed_projects': 27,
                'hourly_rate': 4500,
                'available': False,
                'sort_order': 33
            },
            {
                'name': 'Ксения Логинова',
                'role': 'Performance Tester',
                'category': 'QA',
                'description': 'Нагрузочное тестирование и профилирование. Нахожу узкие места до того, как их найдут пользователи.',
                'education_years': 3,
                'education_place': 'СПбПУ + ISTQB Performance Testing',
                'project1_name': 'Нагрузочное тестирование',
                'project1_description': 'Выявление bottleneck при 100K RPS',
                'project2_name': 'Оптимизация API',
                'project2_description': 'Снижение latency P99 с 2s до 100ms',
                'email': 'ksenia@experts.ru',
                'phone': '+7 (999) 114-56-67',
                'telegram': '@ksenia_perf',
                'skills': 'JMeter, Gatling, k6, Grafana, APM, Profiling',
                'rating': 4.7,
                'completed_projects': 20,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 34
            },
            {
                'name': 'Руслан Акимов',
                'role': 'AI/ML Researcher',
                'category': 'Data Science',
                'description': 'Исследования в области NLP и Computer Vision. Публикации на NeurIPS и ICML.',
                'education_years': 7,
                'education_place': 'Сколтех, PhD в Machine Learning',
                'project1_name': 'LLM Fine-tuning',
                'project1_description': 'Дообучение языковых моделей для русского языка',
                'project2_name': 'Medical AI',
                'project2_description': 'Диагностика по рентген-снимкам, точность 97%',
                'email': 'ruslan@experts.ru',
                'phone': '+7 (999) 115-67-78',
                'telegram': '@ruslan_ai',
                'skills': 'PyTorch, Transformers, NLP, CV, LLM, RAG, LangChain',
                'rating': 5.0,
                'completed_projects': 11,
                'hourly_rate': 8000,
                'available': True,
                'sort_order': 35
            },
            {
                'name': 'Анастасия Жукова',
                'role': 'Business Analyst',
                'category': 'Management',
                'description': 'Анализ бизнес-процессов и формализация требований. Мост между бизнесом и разработкой.',
                'education_years': 4,
                'education_place': 'ФинУниверситет + CBAP',
                'project1_name': 'Автоматизация процессов',
                'project1_description': 'Описание и оптимизация 200+ бизнес-процессов',
                'project2_name': 'Требования для ERP',
                'project2_description': 'Полный пакет ТЗ для внедрения SAP',
                'email': 'anastasia@experts.ru',
                'phone': '+7 (999) 116-78-89',
                'telegram': '@anastasia_ba',
                'skills': 'BPMN, UML, Confluence, SQL, Power BI, User Stories',
                'rating': 4.8,
                'completed_projects': 35,
                'hourly_rate': 3500,
                'available': True,
                'sort_order': 36
            },
            {
                'name': 'Георгий Рябов',
                'role': 'Rust Developer',
                'category': 'Backend',
                'description': 'Системное программирование на Rust. Высокопроизводительные и безопасные решения.',
                'education_years': 4,
                'education_place': 'МФТИ, системное программирование',
                'project1_name': 'Торговый движок',
                'project1_description': 'Matching engine для биржи на Rust, latency < 1μs',
                'project2_name': 'WebAssembly runtime',
                'project2_description': 'Кастомный WASM-рантайм для edge computing',
                'email': 'georgy@experts.ru',
                'phone': '+7 (999) 117-89-90',
                'telegram': '@georgy_rust',
                'skills': 'Rust, C++, WebAssembly, Tokio, Linux Kernel, LLVM',
                'rating': 4.9,
                'completed_projects': 13,
                'hourly_rate': 7000,
                'available': True,
                'sort_order': 37
            },
            {
                'name': 'Лариса Фомина',
                'role': '3D Artist',
                'category': 'Design',
                'description': 'Создание 3D-моделей, визуализаций и анимаций для игр, рекламы и архитектурных проектов.',
                'education_years': 4,
                'education_place': 'Школа дизайна НИУ ВШЭ',
                'project1_name': 'Архитектурная визуализация',
                'project1_description': 'Фотореалистичные рендеры жилого комплекса',
                'project2_name': 'Игровые ассеты',
                'project2_description': 'Low-poly модели для мобильной игры',
                'email': 'larisa@experts.ru',
                'phone': '+7 (999) 118-90-01',
                'telegram': '@larisa_3d',
                'skills': 'Blender, ZBrush, Substance Painter, Maya, Unreal Engine',
                'rating': 4.7,
                'completed_projects': 42,
                'hourly_rate': 3500,
                'available': False,
                'sort_order': 38
            },
            {
                'name': 'Вадим Козырев',
                'role': 'Platform Engineer',
                'category': 'DevOps',
                'description': 'Построение Internal Developer Platforms. Ускоряю разработку через автоматизацию и стандартизацию.',
                'education_years': 5,
                'education_place': 'ИТМО + CKA, CKAD',
                'project1_name': 'Developer Portal',
                'project1_description': 'Backstage-портал для 200+ разработчиков',
                'project2_name': 'GitOps платформа',
                'project2_description': 'ArgoCD + Crossplane для self-service инфраструктуры',
                'email': 'vadim@experts.ru',
                'phone': '+7 (999) 119-01-12',
                'telegram': '@vadim_platform',
                'skills': 'Kubernetes, ArgoCD, Backstage, Crossplane, Helm, Go',
                'rating': 4.8,
                'completed_projects': 15,
                'hourly_rate': 6000,
                'available': True,
                'sort_order': 39
            },
            {
                'name': 'Елизавета Панова',
                'role': 'Marketing Analyst',
                'category': 'Marketing',
                'description': 'Аналитика маркетинговых кампаний и ROI-оптимизация. Работа с большими рекламными бюджетами.',
                'education_years': 3,
                'education_place': 'РЭУ Плеханова + Google Analytics, Meta Blueprint',
                'project1_name': 'Performance-маркетинг',
                'project1_description': 'Снижение CPA на 45% при росте объёмов',
                'project2_name': 'Attribution модель',
                'project2_description': 'Multi-touch attribution для омниканальности',
                'email': 'elizaveta@experts.ru',
                'phone': '+7 (999) 120-12-23',
                'telegram': '@elizaveta_marketing',
                'skills': 'Google Analytics, Tableau, SQL, Python, Яндекс.Директ, Meta Ads',
                'rating': 4.6,
                'completed_projects': 29,
                'hourly_rate': 3000,
                'available': True,
                'sort_order': 40
            }
        ]

        for data in specialists_data:
            specialist = Specialist(**data)
            db_sess.add(specialist)

        db_sess.commit()
        print("✅ 40 специалистов создано!")

    if db_sess.query(User).count() == 0:
        print("👤 Создание администратора...")
        admin = User(
            username='admin',
            email='admin@experts.ru',
            is_admin=True
        )
        admin.set_password('admin123')
        db_sess.add(admin)
        db_sess.commit()
        print("✅ Админ создан: admin / admin123")

    print("\n🚀 База данных инициализирована!")


# ==================== ЗАПУСК ====================
if __name__ == '__main__':
    init_database()
    print("=" * 60)
    print("🌐 Сервер запущен!")
    print("📍 Адрес: http://127.0.0.1:5000")
    print("👤 Логин: admin | Пароль: admin123")
    print("📚 API: /api/specialists")
    print("=" * 60)
    app.run(debug=True, port=5000)

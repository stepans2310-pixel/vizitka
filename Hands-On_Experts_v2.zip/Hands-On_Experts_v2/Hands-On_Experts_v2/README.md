# 🚀 Hands-On Experts

**Платформа для поиска IT-специалистов**

---

## 📋 Применённые технологии (для Яндекс.Лицея)

| Технология | Реализация |
|------------|------------|
| ✅ **requirements.txt** | Управление зависимостями (Flask, SQLAlchemy, Flask-Login, gunicorn) |
| ✅ **Bootstrap 5** | Адаптивный UI, иконки, компоненты |
| ✅ **ORM-модели** | SQLAlchemy: Specialist, User |
| ✅ **Регистрация и авторизация** | Flask-Login: вход, регистрация, выход, роли (admin/user) |
| ✅ **Загрузка файлов** | Аватары специалистов (static/uploads/) |
| ✅ **REST API** | 9 endpoints: GET/POST/PUT/DELETE |
| ✅ **Хранение данных** | SQLite (team_portfolio.db) |
| ✅ **Хостинг** | Готово к деплою (PythonAnywhere/Render/Railway) |

---

## ✨ Возможности

- **20 специалистов** с детальными профилями
- **Поиск и фильтрация** по имени, навыкам, категории
- **Анимации** с AOS библиотекой
- **Счётчики** с анимацией чисел
- **Улучшенный дизайн** с плавными переходами
- **Категории** специалистов (Backend, Frontend, DevOps и др.)
- **Почасовая ставка** для каждого специалиста
- **Статистика** в админ-панели

## 📁 Структура проекта

```
flask_project/
├── app.py                 # Главный файл Flask
├── requirements.txt       # Зависимости
├── team_portfolio.db      # База данных (создаётся автоматически)
│
├── data/                  # Модели базы данных
│   ├── __init__.py
│   ├── db_session.py
│   ├── specialist.py
│   ├── user.py
│   └── __all_models.py
│
├── templates/             # HTML шаблоны
│   ├── base.html
│   ├── index.html
│   ├── auth.html
│   ├── admin.html
│   └── error.html
│
└── static/
    └── css/
        └── style.css
```

## 🚀 Запуск

### 1. Установите зависимости
```bash
cd flask_project
pip install -r requirements.txt
```

### 2. Запустите приложение
```bash
python app.py
```

### 3. Откройте в браузере
```
http://127.0.0.1:5000
```

### 4. Войдите как администратор
- **Логин:** `admin`
- **Пароль:** `admin123`

## 🔧 API Endpoints

| Метод | Endpoint | Описание |
|-------|----------|----------|
| GET | `/api/specialists` | Список всех специалистов |
| GET | `/api/specialists/<id>` | Информация о специалисте |
| GET | `/api/specialists/search?q=python` | Поиск специалистов |
| GET | `/api/stats` | Статистика платформы |
| GET | `/api/categories` | Категории специалистов |
| POST | `/api/specialists` | Создать специалиста (нужен X-API-Key) |
| PUT | `/api/specialists/<id>` | Обновить специалиста |
| DELETE | `/api/specialists/<id>` | Удалить специалиста |

**API-ключ:** `hands-on-experts-api-key-2024`

---



## 👥 Категории специалистов

- Backend
- Frontend  
- Full-Stack
- DevOps
- Data Science
- Mobile
- QA
- Design
- Management
- Security
- GameDev
- Blockchain
- Embedded
- Enterprise
- Marketing
- Documentation

## 🎨 Дизайн

- Космическая тёмная тема со звёздами
- Фиолетовый акцентный цвет
- Плавные анимации (AOS)
- Адаптивный дизайн
- Bootstrap 5 + кастомные стили
- Glassmorphism эффекты

---

## 📁 Структура файлов для деплоя

```
flask_project/
├── app.py              # Основное приложение
├── wsgi.py             # WSGI entry point для хостинга
├── requirements.txt    # Зависимости Python
├── Procfile            # Для Render/Heroku/Railway
├── runtime.txt         # Версия Python
├── data/               # ORM модели
├── templates/          # HTML шаблоны (Jinja2)
├── static/             # CSS, загруженные файлы
└── team_portfolio.db   # SQLite база (создаётся автоматически)
```

---

---

## 🎓 Оценка проекта (для Яндекс.Лицея)

| Критерий | Баллы | Выполнение |
|----------|-------|------------|
| Объём кода | 15/15 | **4,075 строк** (Python + HTML + CSS) |
| Чистота кода | 5/5 | PEP 8, docstrings, константы |
| Качество проектирования | 20/20 | ORM-классы, модули, MVC |
| Применённые технологии | 20/20 | Все технологии из модуля |
| Оригинальная идея | 10/10 | Платформа для IT-специалистов |
| Работоспособность | ×1 | Полностью работает |

---

## 📽️ Презентация

Открой файл `presentation.html` в браузере — это интерактивная презентация для защиты проекта.

**Навигация:**
- ← → — переключение слайдов
- Пробел — следующий слайд
- Свайп на мобильных

---

## 👨‍💻 Авторы

Протасов Фёдор и Шепелев Степан | Яндекс.Лицей 2026
